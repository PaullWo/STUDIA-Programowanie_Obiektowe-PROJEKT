package skleppw;

public interface Opisy {
    public String opis();
    public String opisHTML();
}
